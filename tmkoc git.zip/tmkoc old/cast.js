var sm=document.getElementsByClassName('text-muted-more');
for(let i=0; i<sm.length; i++){
    var smm=sm[i];
    smm.addEventListener('click',showmore,false);
    function showmore(){
        var par=smm.parentElement;
        par.setAttribute('style','display: none;');
        var par=par.nextElementSibling;
        par.setAttribute('style','display: initial;');
    }
}
var sl=document.getElementsByClassName('text-muted-less');
for(let i=0;i<sl.length;i++){
    var sll=sl[i];
    sll.addEventListener('click',showless,false);
    function showless(){
        var par=sll.parentElement;
        par.setAttribute('style','display: none;');
        var par=par.previousElementSibling;
        par.setAttribute('style','display: initial;');
    }
}